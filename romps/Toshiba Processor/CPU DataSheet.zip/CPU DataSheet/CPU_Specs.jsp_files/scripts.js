/* browser detection */

myBrowser=navigator.appName;
var NS4 = (myBrowser.indexOf("Netscape")!=-1);
var IE = (myBrowser.indexOf("Explorer")!=-1);
var NS6 = false;

if (navigator.appVersion.charAt(0) == "5") 
{
	if (NS4)
	{
		NS6 = true;
		NS4 = false;
	} 
}

/* MS windows flag */
var isWin = navigator.userAgent.indexOf("Win")!=-1;

var hide = 'hidden';
var show = 'visible';


/* reload the page, refresh all values and units  */		
function reload(page)
{   var value = document.UnitSystem.UnitList.options[document.UnitSystem.UnitList.selectedIndex].text;
    var action = page + "&UnitSystem=" + value;
    window.open(action, target="_top");
} 


function actionCancel()
{
	if( top && top.window && top.window.external && top.window.external.ptc )
	{	top.window.external.ptc("0JSCloseWindow");
	}
	else
	{	window.close();
	}
}

/* sets the unit system name as a value of document.mainForm.UnitSystem component */
function getUnitSystem()
{   var selected = document.SystemForm.UnitList.selectedIndex;
    document.mainForm.UnitSystem.value = document.SystemForm.UnitList.options[selected].text;
}

/* Returns style for a given layer and a given row (or null if requested style does not exist). */
function getStyle(whichDiv, rowNumber)
{

	if(NS6)
	{
		var x = eval("document.getElementById('" + whichDiv + rowNumber + "')");
		if(x)
		{
			return x.style;
		}
	}
	if(IE)
	{
		var x = eval("document.all." + whichDiv + rowNumber);

		if(x)
		{
			return x.style;
		}
		return x;
	}
}	//getStyle


/* almost the same as window.open(), the only difference when invoked from Wildfire  */
/* param 'name' used only for Wildfire, to construct the title of Wildfire window */
function wfWindowOpen(url, opts)
{
	if( top && top.window && top.window.external && top.window.external.ptc )
	{	//Detected Wildfire browser.
		window.open(url, target="_top", opts);
	}
	else
	{	//Configure target="_blank" to open pop-up window
		window.open(url, target="_top", opts);
	}
}


/* Assigns a given value to mainForm field with a given name. */
function changed(field, theValue)
{
	document.mainForm.elements[field].value = theValue;
}


