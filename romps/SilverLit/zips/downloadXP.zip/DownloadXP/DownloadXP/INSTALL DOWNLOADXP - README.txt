SIMPLE INSTALLATION:

Click on ALLOWIO.exe to start it. It automatically installs the PortTalk driver, if an error prevents that installation just copy the file, PORTTALK.sys to your Windows/System32 directory.

Click DOWNLOADXP.cmd and copy a personality to your cartrdige.

The Z-Cybie cartridge is included and you can download more from:
http://aibohack.com/icybie/index.html


The complete AllowIO/PortTalk archive is included if you need it. It contains source code and applicable headers and examples to include AllowIO in your own applications.



NOTES: Setting your Bios.

Set your Parallel port to the simplest function first, to see what works best for your system - Bi-Directional seems to be the most reliable.

From WindowsXP, under Change a Setting - Control Panels - System:

1 - Select Hardware and then click Device Manager.

2 - Click the + next to Ports in the list of hardware

3 - Right-Click Printer Port, and select Properties

4 - Click Port Settings, and make sure Use Any Interrupt Assigned To A Port is selected.

5 - Click Resources and note the IO range and IRQ
    (These should be 0378-037F and an IRQ of 07 or something similar.)

    The 0378-037F range is what works perfectly on my system.


Now your ready...Download Download Download!



Notes:

These programs are provided in combination with the DownloadXP.cmd file for your convenience, but their respective creators hold copyrights to them.

Downloader.exe is the property of Silverlit, and disributed here for non-commercial use and is copyrighted by Silverlit:
http://www.silverlit.com/news.html


AllowIO/PortTalk is freely available, and the latest version can be downloaded from the programmers at:
http://www.beyondlogic.org/porttalk/porttalk.htm

Please, use responsibly.


:) -Z- http://groups.yahoo.com/group/i-cybie

