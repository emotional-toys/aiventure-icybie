// self destruct program

#include "ic.h"

/////////////////////////////////////////////////////


void main()
{
    printf("Hello world!\n");
}
