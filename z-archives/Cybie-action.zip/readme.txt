			*** Cybie action ***
			Sept. 12, 2002
Copyright(C) Silverlit Toys Manufactory Ltd., Allrights reserved

The program contains 209 I-Cybie animations which you can play by pressing the keys on I-Cybie remote control. 
Each animation has its own code number -- please see file Cybie-action-List for details.

Remote control Key Definition:
=============================
Key "1" - Digit "1"
Key "2" - Digit "2"
Key "3" - Digit "3"
Key "4" - Digit "4"
Key "5" - Digit "5"
Key "6" - Digit "6"
Key "7" - Digit "7"
Key "8" - Digit "8"
Key "9" - Digit "9"
Key "10" - Digit "0"
Key "11" - Neutral Stand Animation 
Key "12" - Stop animation
"Small Circle button" - Clear all input digit values
"Large Circle button" - Enter to confirm the input digit value


Operating Procedure:
====================

1. Plug in the cartridge and power on I-Cybie.
   (*** Please unplug an I-Cybie's battery before plug in Cybie-action cartridge)

2. I-Cybie Both eyes turn red.

3. Press the first digit of the code number, eg. #123. 
   After press "1", I-Cybie's eyes turn Left Orange and Right Off. 
   If correct, press "Large button" to confirm. I-Cybie's eyes turn Both Orange. 
   If wrong, press "Small button" to clear all input value. And goto Step 2 again.

4. Next, Press the second digit of the code number, eg. #123. 
   After press "2", I-Cybie's eyes turn Left Red and Right Off. 
   If correct, press "Large button" to confirm. I-Cybie's eyes turn Both Red. 
   If wrong, press "Small button" to clear all input value. And goto Step 2 again.

5. Finally, Press the third digit of the code number, eg. #123.
   After press "3", I-Cybie's eyes turn Left Green and Right Off. 
   If correct, press "Large button" to confirm. Icybie's eyes turn Both Green. 
   If wrong, press "Small button" to clear all input value. And goto Step 2 again.

6. After the user enters the code number, I-cybie will do the animation.
   (*** If stall motor happened, please remove battery pack, then make it to neutral 
   stand by manual.)

7. When I-Cybie finishs the animation, it will goto step 2.


I-Cybie Eye LED pattern when input animation code
==========================================================
Digit		After Input Digit	After confirm Digit
		(left, Right)		(left, Right)
-----------------------------------------------------------
First		Orange, Off		Orange, Orange
Second		Red, Off			Red, Red
Third		Green, Off		Green, Green


===========================================================================
  Silverlit Toys Mfg. Ltd.		Web:   http://www.silverlit.com
===========================================================================