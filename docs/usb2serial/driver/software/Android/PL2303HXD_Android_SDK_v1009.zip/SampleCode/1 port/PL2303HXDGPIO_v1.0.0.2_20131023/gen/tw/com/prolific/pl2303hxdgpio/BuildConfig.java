/** Automatically generated file. DO NOT MODIFY */
package tw.com.prolific.pl2303hxdgpio;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}