/** Automatically generated file. DO NOT MODIFY */
package com.prolific.pluartmultisimpletest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}