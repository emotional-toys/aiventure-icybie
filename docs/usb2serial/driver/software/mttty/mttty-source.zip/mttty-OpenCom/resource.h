//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MTTTY.RC
//
#define IDR_MTTTYMENU                   101
#define IDR_MTTTYACCELERATOR            102
#define IDI_APPICON                     103
#define IDD_TOOLBARSETTINGS             103
#define ID_TTYWINDOW                    103
#define IDD_ABOUT                       104
#define IDD_STATUSDIALOG                105
#define IDD_COMMEVENTSDLG               107
#define IDD_FLOWCONTROLDLG              108
#define IDI_APPICON2                    109
#define IDI_APPICON3                    110
#define IDD_TIMEOUTSDLG                 110
#define IDI_APPICON4                    111
#define IDD_GETADWORD                   111
#define IDC_PORTCOMBO                   1000
#define IDC_BAUDCOMBO                   1001
#define IDC_PARITYCOMBO                 1002
#define IDC_DATABITSCOMBO               1003
#define IDC_STOPBITSCOMBO               1004
#define IDC_STATCTS                     1004
#define IDC_STATDSR                     1005
#define IDC_STATRING                    1006
#define IDC_STATRLSD                    1007
#define IDC_LOCALECHOCHK                1008
#define IDC_DISPLAYERRORSCHK            1009
#define IDC_FONTBTN                     1010
#define IDC_ABORTBTN                    1011
#define IDC_TRANSFERPROGRESS            1013
#define IDC_MODEMSTATUSGRP              1018
#define IDC_COMMEVENTSBTN               1019
#define IDC_EVBREAKBTN                  1020
#define IDC_EVCTSBTN                    1021
#define IDC_EVDSRBTN                    1022
#define IDC_EVERRBTN                    1023
#define IDC_EVRINGBTN                   1024
#define IDC_EVRLSDBTN                   1025
#define IDC_EVRXCHARBTN                 1026
#define IDC_EVRXFLAGBTN                 1027
#define IDC_EVTXEMPTYBTN                1028
#define IDC_FLAGEDIT                    1029
#define IDC_DEFAULTSBTN                 1030
#define IDC_LFBTN                       1032
#define IDC_AUTOWRAPCHK                 1033
#define IDC_STATUSEDIT                  1034
#define IDC_FLAGCHAR                    1036
#define IDC_FLOWCONTROLBTN              1039
#define IDC_CTSOUTCHK                   1040
#define IDC_DSROUTCHK                   1041
#define IDC_DTRCONTROLCOMBO             1043
#define IDC_DSRINCHK                    1044
#define IDC_XONXOFFOUTCHK               1045
#define IDC_XONXOFFINCHK                1046
#define IDC_XONLIMITEDIT                1047
#define IDC_XOFFLIMITEDIT               1048
#define IDC_XONCHAREDIT                 1049
#define IDC_XOFFCHAREDIT                1050
#define IDC_RTSCONTROLCOMBO             1051
#define IDC_RTSCTSBTN                   1052
#define IDC_XOFFXONBTN                  1053
#define IDC_XONCHARDISP                 1054
#define IDC_XOFFCHARDISP                1055
#define IDC_PICTURE                     1056
#define IDC_DTRDSRBTN                   1056
#define IDC_TIMEOUTSBTN                 1057
#define IDC_READINTERVALEDIT            1058
#define IDC_READMULTIPLIEREDIT          1059
#define IDC_READCONSTANTEDIT            1060
#define IDC_WRITEMULTIPLIEREDIT         1061
#define IDC_WRITECONSTANTEDIT           1062
#define IDC_NONEBTN                     1064
#define IDC_OSVERSIONINFO               1065
#define IDC_TXAFTERXOFFSENTCHK          1066
#define IDC_CTSHOLDCHK                  1067
#define IDC_DSRHOLDCHK                  1068
#define IDC_RLSDHOLDCHK                 1069
#define IDC_XOFFHOLDCHK                 1070
#define IDC_XOFFSENTCHK                 1071
#define IDC_EOFSENTCHK                  1072
#define IDC_TXIMCHK                     1073
#define IDC_TXCHAREDIT                  1074
#define IDC_RXCHAREDIT                  1075
#define IDC_NOREADINGCHK                1076
#define IDC_NOWRITINGCHK                1077
#define IDC_NOSTATUSCHK                 1078
#define IDC_NOEVENTSCHK                 1079
#define IDC_DWORDSTATIC                 1081
#define IDC_DWORDEDIT                   1082
#define IDC_DISPLAYTIMEOUTS             1083
#define ID_FILE_EXIT                    40001
#define ID_HELP_ABOUTMTTTY              40002
#define ID_FILE_CONNECT                 40004
#define ID_FILE_DISCONNECT              40005
#define ID_TTY_CLEAR                    40008
#define ID_TRANSFER_SENDFILETEXT        40010
#define ID_TRANSFER_RECEIVEFILETEXT     40011
#define ID_TRANSFER_SENDREPEATEDLY      40012
#define ID_TRANSFER_ABORTSENDING        40016
#define ID_TRANSFER_ABORTREPEATEDSENDING 40018
#define IDC_STATIC                      65535

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40021
#define _APS_NEXT_CONTROL_VALUE         1084
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
