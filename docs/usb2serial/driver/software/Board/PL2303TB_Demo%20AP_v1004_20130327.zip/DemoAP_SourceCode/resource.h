//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Sample_PL2303TB.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SAMPLE_PL2303TB_DIALOG      102
#define IDR_MAINFRAME                   128
#define IDC_BTN_OPEN                    1000
#define IDC_COMBO_PORT                  1001
#define IDC_LIST_COMMAND_RESPONSE       1002
#define IDC_CHK_GP3_ENABLE              1003
#define IDC_BTN_GP2_GET                 1004
#define IDC_BUTTON1                     1005
#define IDC_COMBO_GP0_CLOCK             1006
#define IDC_COMBO_GP1_CLOCK             1007
#define IDC_COMBO_PI0_LED               1008
#define IDC_COMBO_PI1_LED               1009
#define IDC_SCROLLBAR_PWM0_FREQ         1010
#define IDC_SCROLLBAR_PWM0_DUTY         1011
#define IDC_COMBO_PWM                   1012
#define IDC_BTN_GP2_SET                 1013
#define IDC_BTN_GP3_GET                 1014
#define IDC_BTN_GP3_SET                 1015
#define IDC_EDIT_GP2_VAL                1016
#define IDC_EDIT_GP3_VAL                1017
#define IDC_BTN_GP4_GET                 1018
#define IDC_BTN_GP4_SET                 1019
#define IDC_EDIT_GP4_VAL                1020
#define IDC_CHK_GP5_ENABLE              1021
#define IDC_BTN_GP5_GET                 1022
#define IDC_BTN_GP5_SET                 1023
#define IDC_EDIT_GP5_VAL                1024
#define IDC_BTN_GP6_GET                 1025
#define IDC_BTN_GP6_SET                 1026
#define IDC_EDIT_GP6_VAL                1027
#define IDC_CHK_GP7_ENABLE              1028
#define IDC_BTN_GP7_GET                 1029
#define IDC_BTN_GP7_SET                 1030
#define IDC_EDIT_GP7_VAL                1031
#define IDC_CHK_GP8_ENABLE              1032
#define IDC_BTN_GP8_GET                 1033
#define IDC_BTN_GP8_SET2                1034
#define IDC_EDIT_GP8_VAL                1035
#define IDC_BTN_GP9_GET                 1036
#define IDC_BTN_GP9_SET                 1037
#define IDC_EDIT_GP9_VAL                1038
#define IDC_CHK_GP10_ENABLE             1039
#define IDC_BTN_GP10_GET                1040
#define IDC_BTN_GP10_SET                1041
#define IDC_EDIT_GP10_VAL               1042
#define IDC_CHK_GP11_ENABLE             1043
#define IDC_BTN_GP11_GET                1044
#define IDC_BTN_GP11_SET                1045
#define IDC_EDIT_GP11_VAL               1046
#define IDC_CHECK_GPO_CLOECK            1047
#define IDC_CHECK_GP1_CLOECK            1048
#define IDC_BUTTON2                     1049
#define IDC_BUTTON3                     1050
#define IDC_BUTTON4                     1051
#define IDC_BUTTON5                     1052
#define IDC_BUTTON6                     1053
#define IDC_CHECK_GP0_LED               1055
#define IDC_CHECK_GP1_LED               1059
#define IDC_CHK_GP0_ENABLE              1066
#define IDC_BTN_GP0_GET                 1067
#define IDC_BTN_GP0_SET                 1068
#define IDC_EDIT_GP0_VAL                1069
#define IDC_CHK_GP1_ENABLE              1070
#define IDC_BTN_GP1_GET                 1071
#define IDC_BTN_GP1_SET                 1072
#define IDC_EDIT_GP1_VAL                1073
#define IDC_CHK_GP2_ENABLE              1074
#define IDC_CHK_GP4_ENABLE              1075
#define IDC_CHK_GP6_ENABLE              1076
#define IDC_CHK_GP9_ENABLE              1077

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1054
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
