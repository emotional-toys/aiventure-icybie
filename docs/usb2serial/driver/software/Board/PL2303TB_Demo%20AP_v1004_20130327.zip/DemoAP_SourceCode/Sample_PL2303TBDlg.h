// Sample_PL2303TBDlg.h : header file
//

#pragma once
#include "afxwin.h"


// CSample_PL2303TBDlg dialog
class CSample_PL2303TBDlg : public CDialog
{
// Construction
public:
	CSample_PL2303TBDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_SAMPLE_PL2303TB_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	virtual BOOL CreThrd();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnOpen();

	void AddResponseString(CString& str);
	HANDLE hCOM;
	CString m_strPort;
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedChkGp0Enable();
	
	 CString str;
	 bool m_bGP0Enable;
	 bool m_bGP1Enable;
	 bool m_bGP2Enable;
	 bool m_bGP3Enable;
	 bool m_bGP4Enable;
	 bool m_bGP5Enable;
	 bool m_bGP6Enable;
	 bool m_bGP7Enable;
	 bool m_bGP8Enable;
	 bool m_bGP9Enable;
	 bool m_bGP10Enable;
	 bool m_bGP11Enable;

	 __int8 GPIO_Address;
	 BYTE val;
	 __int8 PWM_Address;

	 int errCode;
	 afx_msg void OnBnClickedChkGp1Enable();
	 afx_msg void OnBnClickedChkGp2Enable();
	 afx_msg void OnBnClickedChkGp3Enable();
	 afx_msg void OnBnClickedChkGp4Enable();
	 afx_msg void OnBnClickedChkGp5Enable();
	 afx_msg void OnBnClickedChkGp6Enable();
	 afx_msg void OnBnClickedChkGp7Enable();
	 afx_msg void OnBnClickedChkGp8Enable();
	 afx_msg void OnBnClickedChkGp9Enable();
	 afx_msg void OnBnClickedChkGp10Enable();
	 afx_msg void OnBnClickedChkGp11Enable();
	
	 afx_msg void OnBnClickedBtnGp0Get();
	 afx_msg void OnBnClickedBtnGp1Get();
	 afx_msg void OnBnClickedBtnGp2Get();
	 afx_msg void OnBnClickedBtnGp3Get();
	 afx_msg void OnBnClickedBtnGp4Get();
	 afx_msg void OnBnClickedBtnGp5Get();
	 afx_msg void OnBnClickedBtnGp6Get();
	 afx_msg void OnBnClickedBtnGp7Get();
	 afx_msg void OnBnClickedBtnGp8Get();
	 afx_msg void OnBnClickedBtnGp9Get();
	 afx_msg void OnBnClickedBtnGp10Get();
	 afx_msg void OnBnClickedBtnGp11Get();
	 afx_msg void OnBnClickedBtnGp0Set();
	 afx_msg void OnBnClickedBtnGp1Set();
	 afx_msg void OnBnClickedBtnGp2Set();
	 afx_msg void OnBnClickedBtnGp3Set();
	 afx_msg void OnBnClickedBtnGp4Set();
	 afx_msg void OnBnClickedBtnGp5Set();
	 afx_msg void OnBnClickedBtnGp6Set();
	 afx_msg void OnBnClickedBtnGp7Set();
	 afx_msg void OnBnClickedBtnGp8Set2();
	 afx_msg void OnBnClickedBtnGp9Set();
	 afx_msg void OnBnClickedBtnGp10Set();
	 afx_msg void OnBnClickedBtnGp11Set();
	 afx_msg void OnBnClickedCheckGpoCloeck();
	 bool m_GPO_CLK_Funcion;
	 bool m_GP1_CLK_Funcion;
	 afx_msg void OnBnClickedCheckGp1Cloeck();
	 afx_msg void OnRButtonDblClk(UINT nFlags, CPoint point);
	 afx_msg void OnBnClickedRadioGp0Clk1();
	 afx_msg void OnCbnSelchangeComboGp0Clock();
	 afx_msg void OnCbnSelchangeComboGp1Clock();
	 afx_msg void OnCbnSelchangeComboPi0Led();
	 afx_msg void OnCbnSelchangeComboPi1Led();
	 BOOL m_PIO_LED_Funcion;
	 afx_msg void OnBnClickedCheckGp0Led();
	 BOOL m_PI1_LED_Funcion;
	 afx_msg void OnBnClickedCheckGp1Led();
	 afx_msg void OnNMThemeChangedScrollbarPwm0Freq(NMHDR *pNMHDR, LRESULT *pResult);
	 CScrollBar m_ScrollBar_PWM_FREQ;
	 afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	 CScrollBar m_ScrollBar_PWM_DUT;
	 afx_msg void OnNMThemeChangedScrollbarPwm0Duty(NMHDR *pNMHDR, LRESULT *pResult);
	 afx_msg void OnCbnSelchangeComboPwm();
	 CString m_PWM_Sel;
	 CString m_GP0_Clock;
	 CString m_GP1_Clock;
	 CString m_PI0_LED;
	 CString m_PI1_LED;
	 afx_msg void OnBnClickedButton2();
	 afx_msg void OnBnClickedButton3();
	 afx_msg BOOL OnDeviceChange(UINT nEventType, DWORD dwData);
	 bool PeekAndPump(void);
	 bool Delay(int delay);
	 bool b_close;
public:
	afx_msg void OnBnClickedButton4();
public:
	afx_msg void OnBnClickedButton5();
	bool setSwp;
	bool setBrz;
	afx_msg void OnBnClickedButton6();
};
