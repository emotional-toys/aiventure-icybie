// Sample_PL2303TBDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Sample_PL2303TB.h"
#include "Sample_PL2303TBDlg.h"
#include <windowsx.h>

#include "lib/PL2303DLL.h"

#include <dbt.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CWinThread* pThreadBrz;
CWinThread* pThreadSwp;
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CSample_PL2303TBDlg dialog




CSample_PL2303TBDlg::CSample_PL2303TBDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSample_PL2303TBDlg::IDD, pParent)
	, m_strPort(_T(""))
	, m_bGP0Enable(false)
	, m_bGP1Enable(false)
	, m_bGP2Enable(false)
	, m_bGP3Enable(false)
	, m_bGP4Enable(false)
	, m_bGP5Enable(false)
	, m_bGP6Enable(false)
	, m_bGP7Enable(false)
	, m_bGP8Enable(false)
	, m_bGP9Enable(false)
	, m_bGP10Enable(false)
	, m_bGP11Enable(false)
	, m_GPO_CLK_Funcion(false)
	, m_GP1_CLK_Funcion(false)
	, m_PIO_LED_Funcion(FALSE)
	, m_PI1_LED_Funcion(FALSE)
	, m_PWM_Sel(_T(""))
	, m_GP0_Clock(_T(""))
	, m_GP1_Clock(_T(""))
	, m_PI0_LED(_T(""))
	, m_PI1_LED(_T(""))
	, setSwp(false)
	, setBrz(false)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSample_PL2303TBDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_CBString(pDX, IDC_COMBO_PORT, m_strPort);
	//	DDX_Control(pDX, IDC_RADIO_GP0_CLK_1, m_GP0_Clock_15);
	DDX_Check(pDX, IDC_CHECK_GP0_LED, m_PIO_LED_Funcion);
	DDX_Check(pDX, IDC_CHECK_GP1_LED, m_PI1_LED_Funcion);
	DDX_Control(pDX, IDC_SCROLLBAR_PWM0_FREQ, m_ScrollBar_PWM_FREQ);
	DDX_Control(pDX, IDC_SCROLLBAR_PWM0_DUTY, m_ScrollBar_PWM_DUT);
	DDX_CBString(pDX, IDC_COMBO_PWM, m_PWM_Sel);
	DDX_CBString(pDX, IDC_COMBO_GP0_CLOCK, m_GP0_Clock);
	DDX_CBString(pDX, IDC_COMBO_GP1_CLOCK, m_GP1_Clock);
	DDX_CBString(pDX, IDC_COMBO_PI0_LED, m_PI0_LED);
	DDX_CBString(pDX, IDC_COMBO_PI1_LED, m_PI1_LED);
}

BEGIN_MESSAGE_MAP(CSample_PL2303TBDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DEVICECHANGE()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BTN_OPEN, &CSample_PL2303TBDlg::OnBnClickedBtnOpen)
	ON_BN_CLICKED(IDCANCEL, &CSample_PL2303TBDlg::OnBnClickedCancel)
	ON_BN_CLICKED(IDC_BUTTON1, &CSample_PL2303TBDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_CHK_GP0_ENABLE, &CSample_PL2303TBDlg::OnBnClickedChkGp0Enable)
	ON_BN_CLICKED(IDC_CHK_GP1_ENABLE, &CSample_PL2303TBDlg::OnBnClickedChkGp1Enable)
	ON_BN_CLICKED(IDC_CHK_GP2_ENABLE, &CSample_PL2303TBDlg::OnBnClickedChkGp2Enable)
	ON_BN_CLICKED(IDC_CHK_GP3_ENABLE, &CSample_PL2303TBDlg::OnBnClickedChkGp3Enable)
	ON_BN_CLICKED(IDC_CHK_GP4_ENABLE, &CSample_PL2303TBDlg::OnBnClickedChkGp4Enable)
	ON_BN_CLICKED(IDC_CHK_GP5_ENABLE, &CSample_PL2303TBDlg::OnBnClickedChkGp5Enable)
	ON_BN_CLICKED(IDC_CHK_GP6_ENABLE, &CSample_PL2303TBDlg::OnBnClickedChkGp6Enable)
	ON_BN_CLICKED(IDC_CHK_GP7_ENABLE, &CSample_PL2303TBDlg::OnBnClickedChkGp7Enable)
	ON_BN_CLICKED(IDC_CHK_GP8_ENABLE, &CSample_PL2303TBDlg::OnBnClickedChkGp8Enable)
	ON_BN_CLICKED(IDC_CHK_GP9_ENABLE, &CSample_PL2303TBDlg::OnBnClickedChkGp9Enable)
	ON_BN_CLICKED(IDC_CHK_GP10_ENABLE, &CSample_PL2303TBDlg::OnBnClickedChkGp10Enable)
	ON_BN_CLICKED(IDC_CHK_GP11_ENABLE, &CSample_PL2303TBDlg::OnBnClickedChkGp11Enable)
	ON_BN_CLICKED(IDC_BTN_GP0_GET, &CSample_PL2303TBDlg::OnBnClickedBtnGp0Get)
	ON_BN_CLICKED(IDC_BTN_GP1_GET, &CSample_PL2303TBDlg::OnBnClickedBtnGp1Get)
	ON_BN_CLICKED(IDC_BTN_GP2_GET, &CSample_PL2303TBDlg::OnBnClickedBtnGp2Get)
	ON_BN_CLICKED(IDC_BTN_GP3_GET, &CSample_PL2303TBDlg::OnBnClickedBtnGp3Get)
	ON_BN_CLICKED(IDC_BTN_GP4_GET, &CSample_PL2303TBDlg::OnBnClickedBtnGp4Get)
	ON_BN_CLICKED(IDC_BTN_GP5_GET, &CSample_PL2303TBDlg::OnBnClickedBtnGp5Get)
	ON_BN_CLICKED(IDC_BTN_GP6_GET, &CSample_PL2303TBDlg::OnBnClickedBtnGp6Get)
	ON_BN_CLICKED(IDC_BTN_GP7_GET, &CSample_PL2303TBDlg::OnBnClickedBtnGp7Get)
	ON_BN_CLICKED(IDC_BTN_GP8_GET, &CSample_PL2303TBDlg::OnBnClickedBtnGp8Get)
	ON_BN_CLICKED(IDC_BTN_GP9_GET, &CSample_PL2303TBDlg::OnBnClickedBtnGp9Get)
	ON_BN_CLICKED(IDC_BTN_GP10_GET, &CSample_PL2303TBDlg::OnBnClickedBtnGp10Get)
	ON_BN_CLICKED(IDC_BTN_GP11_GET, &CSample_PL2303TBDlg::OnBnClickedBtnGp11Get)
	ON_BN_CLICKED(IDC_BTN_GP0_SET, &CSample_PL2303TBDlg::OnBnClickedBtnGp0Set)
	ON_BN_CLICKED(IDC_BTN_GP1_SET, &CSample_PL2303TBDlg::OnBnClickedBtnGp1Set)
	ON_BN_CLICKED(IDC_BTN_GP2_SET, &CSample_PL2303TBDlg::OnBnClickedBtnGp2Set)
	ON_BN_CLICKED(IDC_BTN_GP3_SET, &CSample_PL2303TBDlg::OnBnClickedBtnGp3Set)
	ON_BN_CLICKED(IDC_BTN_GP4_SET, &CSample_PL2303TBDlg::OnBnClickedBtnGp4Set)
	ON_BN_CLICKED(IDC_BTN_GP5_SET, &CSample_PL2303TBDlg::OnBnClickedBtnGp5Set)
	ON_BN_CLICKED(IDC_BTN_GP6_SET, &CSample_PL2303TBDlg::OnBnClickedBtnGp6Set)
	ON_BN_CLICKED(IDC_BTN_GP7_SET, &CSample_PL2303TBDlg::OnBnClickedBtnGp7Set)
	ON_BN_CLICKED(IDC_BTN_GP8_SET2, &CSample_PL2303TBDlg::OnBnClickedBtnGp8Set2)
	ON_BN_CLICKED(IDC_BTN_GP9_SET, &CSample_PL2303TBDlg::OnBnClickedBtnGp9Set)
	ON_BN_CLICKED(IDC_BTN_GP10_SET, &CSample_PL2303TBDlg::OnBnClickedBtnGp10Set)
	ON_BN_CLICKED(IDC_BTN_GP11_SET, &CSample_PL2303TBDlg::OnBnClickedBtnGp11Set)
	ON_BN_CLICKED(IDC_CHECK_GPO_CLOECK, &CSample_PL2303TBDlg::OnBnClickedCheckGpoCloeck)
	ON_BN_CLICKED(IDC_CHECK_GP1_CLOECK, &CSample_PL2303TBDlg::OnBnClickedCheckGp1Cloeck)
	ON_WM_RBUTTONDBLCLK()
//	ON_BN_CLICKED(IDC_RADIO_GP0_CLK_1, &CSample_PL2303TBDlg::OnBnClickedRadioGp0Clk1)
	ON_CBN_SELCHANGE(IDC_COMBO_GP0_CLOCK, &CSample_PL2303TBDlg::OnCbnSelchangeComboGp0Clock)
	ON_CBN_SELCHANGE(IDC_COMBO_GP1_CLOCK, &CSample_PL2303TBDlg::OnCbnSelchangeComboGp1Clock)
	ON_CBN_SELCHANGE(IDC_COMBO_PI0_LED, &CSample_PL2303TBDlg::OnCbnSelchangeComboPi0Led)
	ON_CBN_SELCHANGE(IDC_COMBO_PI1_LED, &CSample_PL2303TBDlg::OnCbnSelchangeComboPi1Led)
	ON_BN_CLICKED(IDC_CHECK_GP0_LED, &CSample_PL2303TBDlg::OnBnClickedCheckGp0Led)
	ON_BN_CLICKED(IDC_CHECK_GP1_LED, &CSample_PL2303TBDlg::OnBnClickedCheckGp1Led)
	ON_NOTIFY(NM_THEMECHANGED, IDC_SCROLLBAR_PWM0_FREQ, &CSample_PL2303TBDlg::OnNMThemeChangedScrollbarPwm0Freq)
	ON_WM_HSCROLL()
	ON_NOTIFY(NM_THEMECHANGED, IDC_SCROLLBAR_PWM0_DUTY, &CSample_PL2303TBDlg::OnNMThemeChangedScrollbarPwm0Duty)
	ON_CBN_SELCHANGE(IDC_COMBO_PWM, &CSample_PL2303TBDlg::OnCbnSelchangeComboPwm)
	ON_BN_CLICKED(IDC_BUTTON2, &CSample_PL2303TBDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CSample_PL2303TBDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &CSample_PL2303TBDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON5, &CSample_PL2303TBDlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON6, &CSample_PL2303TBDlg::OnBnClickedButton6)
END_MESSAGE_MAP()


// CSample_PL2303TBDlg message handlers

BOOL CSample_PL2303TBDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	m_strPort = "COM13";
	m_PWM_Sel = "0_DTR";
	m_GP0_Clock = "1.5";
	m_GP1_Clock = "1.5";
	m_PI0_LED = "TX";
	m_PI1_LED = "TX";

	PWM_Address=0;
	GPIO_Address=0;

	m_ScrollBar_PWM_FREQ.SetScrollRange(1,254,1);
	m_ScrollBar_PWM_FREQ.SetScrollPos(1,1);

	m_ScrollBar_PWM_DUT.SetScrollRange(1,254,1);
	m_ScrollBar_PWM_DUT.SetScrollPos(1,1);


	
	
    UpdateData(FALSE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSample_PL2303TBDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}


BOOL CSample_PL2303TBDlg::OnDeviceChange(UINT nEventType, DWORD dwData)
{

	CString strResponse = "Remove port Successfully!";


	switch(nEventType) {

	 case DBT_DEVICEREMOVECOMPLETE:
		 {
			 if(hCOM != INVALID_HANDLE_VALUE) {
				 CloseHandle(hCOM);
				 hCOM = INVALID_HANDLE_VALUE;
			 }
			 if(!b_close) {
				 if(pThreadBrz){
					 delete pThreadBrz;
					 setBrz = 0;
				 }
				 if(pThreadSwp){
					 delete pThreadSwp;
					 setSwp = 0;
				 }
				 AddResponseString(strResponse);
			 }
			 break;
		 }
	}

	return TRUE;
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSample_PL2303TBDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSample_PL2303TBDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CSample_PL2303TBDlg::AddResponseString(CString& str)
{
	CListBox *lb = (CListBox *)GetDlgItem(IDC_LIST_COMMAND_RESPONSE);
	int nIndex = lb->AddString(str);
	if (nIndex != LB_ERR || nIndex != LB_ERRSPACE)
		lb->SetCurSel(nIndex);
}

void CSample_PL2303TBDlg::OnBnClickedBtnOpen()
{
	// TODO: Add your control notification handler code here
	
	CString tmpStr;
	BOOL bSuccess;
    //CString comStr, tmpStr;
	CComboBox* cb = (CComboBox *)GetDlgItem(IDC_COMBO_PORT);
	int nIndex = cb->GetCurSel();
	if (nIndex != CB_ERR) {
		cb->GetLBText(nIndex, m_strPort);

		
		tmpStr = "\\\\.\\" + m_strPort;
		hCOM = ::CreateFile(tmpStr, GENERIC_READ | GENERIC_WRITE,
				0, NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL);

		CString strResponse = "OPEN " + m_strPort + " port ";
		if (hCOM == INVALID_HANDLE_VALUE)
			strResponse += "FAILED.";
		else {
			strResponse += "Successfully!";
			CreThrd();
			//m_hCOM = hCOM;
			//m_comStr = comStr;
		}
		AddResponseString(strResponse);

		COMMTIMEOUTS cto;

			GetCommTimeouts(hCOM, &cto);

		
			cto.ReadIntervalTimeout = 1;
			cto.ReadTotalTimeoutMultiplier = 0;
			cto.ReadTotalTimeoutConstant = 0;
		  cto.WriteTotalTimeoutMultiplier = 0;
			cto.WriteTotalTimeoutConstant = 0;


		  // Set the time-out parameters for all read/write operations
			// on the port. 
			SetCommTimeouts(hCOM, &cto);

		DCB dcb;
		bSuccess = ::GetCommState(hCOM, &dcb);

		dcb.BaudRate =9600;

		bSuccess = ::SetCommState(hCOM, &dcb);
        if(!bSuccess) {
		strResponse = "SET baud rate status FAILED.";
		AddResponseString(strResponse);
		return;
		}

		b_close= false;
  
		
		/*
		if(hCOM != INVALID_HANDLE_VALUE)
			OnBnClickedBtnSetstatus();
        */
		//OpenSymbolicPort();
	}
}

void CSample_PL2303TBDlg::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
	OnCancel();
}

void CSample_PL2303TBDlg::OnBnClickedButton1()
{
	// TODO: Add your control notification handler code here
	
    CString strResponse;

	if(hCOM != INVALID_HANDLE_VALUE) {
		CloseHandle(hCOM);
		 strResponse= "CLOSE " + m_strPort + " port Successfully!";
		hCOM = INVALID_HANDLE_VALUE;
	}
	AddResponseString(strResponse);
	if(pThreadBrz){
		delete pThreadBrz;
		setBrz = 0;
	}
	if(pThreadSwp){
		delete pThreadSwp;
		setSwp = 0;
	}

	b_close= true;

	//OnCancel();
}

void CSample_PL2303TBDlg::OnBnClickedChkGp0Enable()
{
	// TODO: Add your control notification handler code here
    
	m_bGP0Enable = m_bGP0Enable ? false : true;

	CButton *btn = (CButton *)GetDlgItem(IDC_CHK_GP0_ENABLE);
	btn->SetCheck(m_bGP0Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP0_SET);
	btn->EnableWindow(m_bGP0Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP0_GET);
	btn->EnableWindow(!m_bGP0Enable);

	CEdit *ed = (CEdit *)GetDlgItem(IDC_EDIT_GP0_VAL);
	ed->EnableWindow(m_bGP0Enable);

	GPIO_Address=0;

	if((errCode = PL2303_12GPIO_ENABLE(hCOM, GPIO_Address,  m_bGP0Enable)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_ENABLE GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_12GPIO_ENABLE GPIO_%d Successfully!",GPIO_Address);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedChkGp1Enable()
{
	// TODO: Add your control notification handler code here
	m_bGP1Enable = m_bGP1Enable ? false : true;

	CButton *btn = (CButton *)GetDlgItem(IDC_CHK_GP1_ENABLE);
	btn->SetCheck(m_bGP1Enable);

		
	btn = (CButton *)GetDlgItem(IDC_BTN_GP1_SET);
	btn->EnableWindow(m_bGP1Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP1_GET);
	btn->EnableWindow(!m_bGP1Enable);

	CEdit *ed = (CEdit *)GetDlgItem(IDC_EDIT_GP1_VAL);
	ed->EnableWindow(m_bGP1Enable);

	GPIO_Address=1;

	if((errCode = PL2303_12GPIO_ENABLE(hCOM, GPIO_Address,  m_bGP1Enable)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_ENABLE GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_12GPIO_ENABLE GPIO_%d Successfully!",GPIO_Address);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedChkGp2Enable()
{
	// TODO: Add your control notification handler code here
	m_bGP2Enable = m_bGP2Enable ? false : true;

	CButton *btn = (CButton *)GetDlgItem(IDC_CHK_GP2_ENABLE);
	btn->SetCheck(m_bGP2Enable);

    btn = (CButton *)GetDlgItem(IDC_BTN_GP2_SET);
	btn->EnableWindow(m_bGP2Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP2_GET);
	btn->EnableWindow(!m_bGP2Enable);

	CEdit *ed = (CEdit *)GetDlgItem(IDC_EDIT_GP2_VAL);
	ed->EnableWindow(m_bGP2Enable);

	GPIO_Address=2;

	if((errCode = PL2303_12GPIO_ENABLE(hCOM, GPIO_Address,  m_bGP2Enable)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_ENABLE GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_12GPIO_ENABLE GPIO_%d Successfully!",GPIO_Address);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedChkGp3Enable()
{
	// TODO: Add your control notification handler code here
	m_bGP3Enable = m_bGP3Enable ? false : true;

	CButton *btn = (CButton *)GetDlgItem(IDC_CHK_GP3_ENABLE);
	btn->SetCheck(m_bGP3Enable);

    btn = (CButton *)GetDlgItem(IDC_BTN_GP3_SET);
	btn->EnableWindow(m_bGP3Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP3_GET);
	btn->EnableWindow(!m_bGP3Enable);

	CEdit *ed = (CEdit *)GetDlgItem(IDC_EDIT_GP3_VAL);
	ed->EnableWindow(m_bGP3Enable);

	GPIO_Address=3;

	if((errCode = PL2303_12GPIO_ENABLE(hCOM, GPIO_Address,  m_bGP3Enable)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_ENABLE GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_12GPIO_ENABLE GPIO_%d Successfully!",GPIO_Address);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedChkGp4Enable()
{
	// TODO: Add your control notification handler code here
	m_bGP4Enable = m_bGP4Enable ? false : true;

	CButton *btn = (CButton *)GetDlgItem(IDC_CHK_GP4_ENABLE);
	btn->SetCheck(m_bGP4Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP4_SET);
	btn->EnableWindow(m_bGP4Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP4_GET);
	btn->EnableWindow(!m_bGP4Enable);

	CEdit *ed = (CEdit *)GetDlgItem(IDC_EDIT_GP4_VAL);
	ed->EnableWindow(m_bGP4Enable);

	GPIO_Address=4;

	if((errCode = PL2303_12GPIO_ENABLE(hCOM, GPIO_Address,  m_bGP4Enable)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_ENABLE GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_12GPIO_ENABLE GPIO_%d Successfully!",GPIO_Address);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedChkGp5Enable()
{
	// TODO: Add your control notification handler code here
	m_bGP5Enable = m_bGP5Enable ? false : true;

	CButton *btn = (CButton *)GetDlgItem(IDC_CHK_GP5_ENABLE);
	btn->SetCheck(m_bGP5Enable);

    btn = (CButton *)GetDlgItem(IDC_BTN_GP5_SET);
	btn->EnableWindow(m_bGP5Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP5_GET);
	btn->EnableWindow(!m_bGP5Enable);

	CEdit *ed = (CEdit *)GetDlgItem(IDC_EDIT_GP5_VAL);
	ed->EnableWindow(m_bGP5Enable);

	GPIO_Address=5;

	if((errCode = PL2303_12GPIO_ENABLE(hCOM, GPIO_Address,  m_bGP5Enable)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_ENABLE GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_12GPIO_ENABLE GPIO_%d Successfully!",GPIO_Address);
	}
	AddResponseString(str);

}

void CSample_PL2303TBDlg::OnBnClickedChkGp6Enable()
{
	// TODO: Add your control notification handler code here
	m_bGP6Enable = m_bGP6Enable ? false : true;

	CButton *btn = (CButton *)GetDlgItem(IDC_CHK_GP6_ENABLE);
	btn->SetCheck(m_bGP6Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP6_SET);
	btn->EnableWindow(m_bGP6Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP6_GET);
	btn->EnableWindow(!m_bGP6Enable);

	CEdit *ed = (CEdit *)GetDlgItem(IDC_EDIT_GP6_VAL);
	ed->EnableWindow(m_bGP6Enable);

	GPIO_Address=6;

	if((errCode = PL2303_12GPIO_ENABLE(hCOM, GPIO_Address,  m_bGP6Enable)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_ENABLE GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_12GPIO_ENABLE GPIO_%d Successfully!",GPIO_Address);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedChkGp7Enable()
{
	// TODO: Add your control notification handler code here
	m_bGP7Enable = m_bGP7Enable ? false : true;

	CButton *btn = (CButton *)GetDlgItem(IDC_CHK_GP7_ENABLE);
	btn->SetCheck(m_bGP7Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP7_SET);
	btn->EnableWindow(m_bGP7Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP7_GET);
	btn->EnableWindow(!m_bGP7Enable);

	CEdit *ed = (CEdit *)GetDlgItem(IDC_EDIT_GP7_VAL);
	ed->EnableWindow(m_bGP7Enable);
	
	GPIO_Address=7;

	if((errCode = PL2303_12GPIO_ENABLE(hCOM, GPIO_Address,  m_bGP7Enable)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_ENABLE GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_12GPIO_ENABLE GPIO_%d Successfully!",GPIO_Address);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedChkGp8Enable()
{
	// TODO: Add your control notification handler code here
	m_bGP8Enable = m_bGP8Enable ? false : true;

	CButton *btn = (CButton *)GetDlgItem(IDC_CHK_GP8_ENABLE);
	btn->SetCheck(m_bGP8Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP8_SET2);
	btn->EnableWindow(m_bGP8Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP8_GET);
	btn->EnableWindow(!m_bGP8Enable);

	CEdit *ed = (CEdit *)GetDlgItem(IDC_EDIT_GP8_VAL);
	ed->EnableWindow(m_bGP8Enable);
		
	GPIO_Address=8;

	if((errCode = PL2303_12GPIO_ENABLE(hCOM, GPIO_Address,  m_bGP8Enable)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_ENABLE GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_12GPIO_ENABLE GPIO_%d Successfully!",GPIO_Address);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedChkGp9Enable()
{
	// TODO: Add your control notification handler code here
	
	m_bGP9Enable = m_bGP9Enable ? false : true;

	CButton *btn = (CButton *)GetDlgItem(IDC_CHK_GP9_ENABLE);
	btn->SetCheck(m_bGP9Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP9_SET);
	btn->EnableWindow(m_bGP9Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP9_GET);
	btn->EnableWindow(!m_bGP9Enable);

	CEdit *ed = (CEdit *)GetDlgItem(IDC_EDIT_GP9_VAL);
	ed->EnableWindow(m_bGP9Enable);
			
	GPIO_Address=9;

	if((errCode = PL2303_12GPIO_ENABLE(hCOM, GPIO_Address,  m_bGP9Enable)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_ENABLE GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_12GPIO_ENABLE GPIO_%d Successfully!",GPIO_Address);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedChkGp10Enable()
{
	// TODO: Add your control notification handler code here
	m_bGP10Enable = m_bGP10Enable ? false : true;

	CButton *btn = (CButton *)GetDlgItem(IDC_CHK_GP10_ENABLE);
	btn->SetCheck(m_bGP10Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP10_SET);
	btn->EnableWindow(m_bGP10Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP10_GET);
	btn->EnableWindow(!m_bGP10Enable);

	CEdit *ed = (CEdit *)GetDlgItem(IDC_EDIT_GP10_VAL);
	ed->EnableWindow(m_bGP10Enable);

	GPIO_Address=10;

	if((errCode = PL2303_12GPIO_ENABLE(hCOM, GPIO_Address,  m_bGP10Enable)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_ENABLE GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_12GPIO_ENABLE GPIO_%d Successfully!",GPIO_Address);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedChkGp11Enable()
{
	// TODO: Add your control notification handler code here
	
	m_bGP11Enable = m_bGP11Enable ? false : true;

	CButton *btn = (CButton *)GetDlgItem(IDC_CHK_GP11_ENABLE);
	btn->SetCheck(m_bGP11Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP11_SET);
	btn->EnableWindow(m_bGP11Enable);

	btn = (CButton *)GetDlgItem(IDC_BTN_GP11_GET);
	btn->EnableWindow(!m_bGP11Enable);

	CEdit *ed = (CEdit *)GetDlgItem(IDC_EDIT_GP11_VAL);
	ed->EnableWindow(m_bGP11Enable);

	GPIO_Address=11;

	if((errCode = PL2303_12GPIO_ENABLE(hCOM, GPIO_Address,  m_bGP11Enable)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_ENABLE GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_12GPIO_ENABLE GPIO_%d Successfully!",GPIO_Address);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp0Get()
{
	// TODO: Add your control notification handler code here

	
	val = 0;

	GPIO_Address=0;
	
	if((errCode = PL2303_12GPIO_GetValue(hCOM, GPIO_Address,  &val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp1Get()
{
	// TODO: Add your control notification handler code here
	val = 0;

	GPIO_Address=1;
	
	if((errCode = PL2303_12GPIO_GetValue(hCOM, GPIO_Address,  &val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp2Get()
{
	// TODO: Add your control notification handler code here
	val = 0;

	GPIO_Address=2;
	
	if((errCode = PL2303_12GPIO_GetValue(hCOM, GPIO_Address,  &val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp3Get()
{
	// TODO: Add your control notification handler code here
	val = 0;

	GPIO_Address=3;
	
	if((errCode = PL2303_12GPIO_GetValue(hCOM, GPIO_Address,  &val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp4Get()
{
	// TODO: Add your control notification handler code here
	val = 0;

	GPIO_Address=4;
	
	if((errCode = PL2303_12GPIO_GetValue(hCOM, GPIO_Address,  &val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp5Get()
{
	// TODO: Add your control notification handler code here
	val = 0;

	GPIO_Address=5;
	
	if((errCode = PL2303_12GPIO_GetValue(hCOM, GPIO_Address,  &val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp6Get()
{
	// TODO: Add your control notification handler code here
	val = 0;

	GPIO_Address=6;
	
	if((errCode = PL2303_12GPIO_GetValue(hCOM, GPIO_Address,  &val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp7Get()
{
	// TODO: Add your control notification handler code here
	val = 0;

	GPIO_Address=7;
	
	if((errCode = PL2303_12GPIO_GetValue(hCOM, GPIO_Address,  &val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp8Get()
{
	// TODO: Add your control notification handler code here
	val = 0;

	GPIO_Address=8;
	
	if((errCode = PL2303_12GPIO_GetValue(hCOM, GPIO_Address,  &val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp9Get()
{
	// TODO: Add your control notification handler code here
	val = 0;

	GPIO_Address=9;
	
	if((errCode = PL2303_12GPIO_GetValue(hCOM, GPIO_Address,  &val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp10Get()
{
	// TODO: Add your control notification handler code here
	val = 0;

	GPIO_Address=10;
	
	if((errCode = PL2303_12GPIO_GetValue(hCOM, GPIO_Address,  &val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp11Get()
{
	// TODO: Add your control notification handler code here
	val = 0;

	GPIO_Address=11;
	
	if((errCode = PL2303_12GPIO_GetValue(hCOM, GPIO_Address,  &val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_GetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp0Set()
{
	// TODO: Add your control notification handler code here
	CEdit* eb = (CEdit *)GetDlgItem(IDC_EDIT_GP0_VAL);
	eb->GetWindowText(str);	
	if(str.IsEmpty()) {
		str = "Please fill in 1 or 0.";
		AddResponseString(str);
		return;
	}

	val = (BYTE)atoi(str);

	GPIO_Address=0;

	if((errCode = PL2303_12GPIO_SetValue(hCOM, GPIO_Address,  val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp1Set()
{
	// TODO: Add your control notification handler code here
	
	CEdit* eb = (CEdit *)GetDlgItem(IDC_EDIT_GP1_VAL);
	eb->GetWindowText(str);	
	if(str.IsEmpty()) {
		str = "Please fill in 1 or 0.";
		AddResponseString(str);
		return;
	}

	val = (BYTE)atoi(str);

	GPIO_Address=1;

	if((errCode = PL2303_12GPIO_SetValue(hCOM, GPIO_Address,  val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp2Set()
{
	// TODO: Add your control notification handler code here
	CEdit* eb = (CEdit *)GetDlgItem(IDC_EDIT_GP2_VAL);
	eb->GetWindowText(str);	
	if(str.IsEmpty()) {
		str = "Please fill in 1 or 0.";
		AddResponseString(str);
		return;
	}

	val = (BYTE)atoi(str);

	GPIO_Address=2;

	if((errCode = PL2303_12GPIO_SetValue(hCOM, GPIO_Address,  val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp3Set()
{
	// TODO: Add your control notification handler code here
	
	CEdit* eb = (CEdit *)GetDlgItem(IDC_EDIT_GP3_VAL);
	eb->GetWindowText(str);	
	if(str.IsEmpty()) {
		str = "Please fill in 1 or 0.";
		AddResponseString(str);
		return;
	}
	
	val = (BYTE)atoi(str);

	GPIO_Address=3;

	if((errCode = PL2303_12GPIO_SetValue(hCOM, GPIO_Address,  val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp4Set()
{
	// TODO: Add your control notification handler code here
	CEdit* eb = (CEdit *)GetDlgItem(IDC_EDIT_GP4_VAL);
	eb->GetWindowText(str);	
	if(str.IsEmpty()) {
		str = "Please fill in 1 or 0.";
		AddResponseString(str);
		return;
	}
		
	val = (BYTE)atoi(str);

	GPIO_Address=4;

	if((errCode = PL2303_12GPIO_SetValue(hCOM, GPIO_Address,  val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp5Set()
{
	// TODO: Add your control notification handler code here
	CEdit* eb = (CEdit *)GetDlgItem(IDC_EDIT_GP5_VAL);
	eb->GetWindowText(str);	
	if(str.IsEmpty()) {
		str = "Please fill in 1 or 0.";
		AddResponseString(str);
		return;
	}
			
	val = (BYTE)atoi(str);

	GPIO_Address=5;

	if((errCode = PL2303_12GPIO_SetValue(hCOM, GPIO_Address,  val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp6Set()
{
	// TODO: Add your control notification handler code here
	CEdit* eb = (CEdit *)GetDlgItem(IDC_EDIT_GP6_VAL);
	eb->GetWindowText(str);	
	if(str.IsEmpty()) {
		str = "Please fill in 1 or 0.";
		AddResponseString(str);
		return;
	}
			
	val = (BYTE)atoi(str);

	GPIO_Address=6;

	if((errCode = PL2303_12GPIO_SetValue(hCOM, GPIO_Address,  val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp7Set()
{
	// TODO: Add your control notification handler code here
	CEdit* eb = (CEdit *)GetDlgItem(IDC_EDIT_GP7_VAL);
	eb->GetWindowText(str);	
	if(str.IsEmpty()) {
		str = "Please fill in 1 or 0.";
		AddResponseString(str);
		return;
	}
			
	val = (BYTE)atoi(str);

	GPIO_Address=7;

	if((errCode = PL2303_12GPIO_SetValue(hCOM, GPIO_Address,  val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp8Set2()
{
	// TODO: Add your control notification handler code here
	CEdit* eb = (CEdit *)GetDlgItem(IDC_EDIT_GP8_VAL);
	eb->GetWindowText(str);	
	if(str.IsEmpty()) {
		str = "Please fill in 1 or 0.";
		AddResponseString(str);
		return;
	}
			
	val = (BYTE)atoi(str);

	GPIO_Address=8;

	if((errCode = PL2303_12GPIO_SetValue(hCOM, GPIO_Address,  val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp9Set()
{
	// TODO: Add your control notification handler code here
	CEdit* eb = (CEdit *)GetDlgItem(IDC_EDIT_GP9_VAL);
	eb->GetWindowText(str);	
	if(str.IsEmpty()) {
		str = "Please fill in 1 or 0.";
		AddResponseString(str);
		return;
	}
			
	val = (BYTE)atoi(str);

	GPIO_Address=9;

	if((errCode = PL2303_12GPIO_SetValue(hCOM, GPIO_Address,  val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp10Set()
{
	// TODO: Add your control notification handler code here
	CEdit* eb = (CEdit *)GetDlgItem(IDC_EDIT_GP10_VAL);
	eb->GetWindowText(str);	
	if(str.IsEmpty()) {
		str = "Please fill in 1 or 0.";
		AddResponseString(str);
		return;
	}
			
	val = (BYTE)atoi(str);

	GPIO_Address=10;

	if((errCode = PL2303_12GPIO_SetValue(hCOM, GPIO_Address,  val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedBtnGp11Set()
{
	// TODO: Add your control notification handler code here
	CEdit* eb = (CEdit *)GetDlgItem(IDC_EDIT_GP11_VAL);
	eb->GetWindowText(str);	
	if(str.IsEmpty()) {
		str = "Please fill in 1 or 0.";
		AddResponseString(str);
		return;
	}
			
	val = (BYTE)atoi(str);

	GPIO_Address=11;

	if((errCode = PL2303_12GPIO_SetValue(hCOM, GPIO_Address,  val)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
		str.Format("PL2303_12GPIO_SetValue GPIO_%d value: %d!",GPIO_Address,val);
	}

	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedCheckGpoCloeck()
{
	// TODO: Add your control notification handler code here

	m_GPO_CLK_Funcion = m_GPO_CLK_Funcion ? false : true;

	
	GPIO_Address=0;

	if((errCode = PL2303_Enable_Clock_Output(hCOM, GPIO_Address,  m_GPO_CLK_Funcion)) != STATUS_SUCCESS) {
		str.Format("PL2303_Enable_Clock_Output GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_Enable_Clock_Output GPIO_%d Successfully!",GPIO_Address);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedCheckGp1Cloeck()
{
	// TODO: Add your control notification handler code here
	m_GP1_CLK_Funcion = m_GP1_CLK_Funcion ? false : true;

	GPIO_Address= 1;

	if((errCode = PL2303_Enable_Clock_Output(hCOM, GPIO_Address,  m_GP1_CLK_Funcion)) != STATUS_SUCCESS) {
		str.Format("PL2303_Enable_Clock_Output GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_Enable_Clock_Output GPIO_%d Successfully!",GPIO_Address);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnRButtonDblClk(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default

	CDialog::OnRButtonDblClk(nFlags, point);
}

void CSample_PL2303TBDlg::OnBnClickedRadioGp0Clk1()
{
	// TODO: Add your control notification handler code here
}

void CSample_PL2303TBDlg::OnCbnSelchangeComboGp0Clock()
{
	// TODO: Add your control notification handler code here
	BYTE valeue;
	CString str_Text;
	CComboBox* cb = (CComboBox *)GetDlgItem(IDC_COMBO_GP0_CLOCK);
	int nIndex = cb->GetCurSel();
	cb->GetLBText(nIndex, str_Text);
	
	switch(nIndex)
	{
	case 0:
		//1.5MHz
		valeue=0;
		break;
	case 1:
		//3MHz
		valeue=1;
		break;
	case 2:
		//6MHz
		valeue=2;
		break;
	case 3:
		//12MHz
		valeue=3;
		break;
	case 4:
		//24MHz
		valeue=4;
		break;
	case 5:
		//48MHz
		valeue=5;
		break;
	default:
		return ; 
	}

	GPIO_Address=0;

	if((errCode = PL2303_SetClock(hCOM, GPIO_Address,  valeue)) != STATUS_SUCCESS) {
		str.Format("PL2303_SetClock GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_SetClock GPIO_%d , %s MHz Successfully!",GPIO_Address, str_Text);
	}
	AddResponseString(str);

}

void CSample_PL2303TBDlg::OnCbnSelchangeComboGp1Clock()
{
	// TODO: Add your control notification handler code here
	BYTE valeue;
	CString str_Text;
	CComboBox* cb = (CComboBox *)GetDlgItem(IDC_COMBO_GP1_CLOCK);
	int nIndex = cb->GetCurSel();
	cb->GetLBText(nIndex, str_Text);
	
	switch(nIndex)
	{
	case 0:
		//1.5MHz
		valeue=0;
		break;
	case 1:
		//3MHz
		valeue=1;
		break;
	case 2:
		//6MHz
		valeue=2;
		break;
	case 3:
		//12MHz
		valeue=3;
		break;
	case 4:
		//24MHz
		valeue=4;
		break;
	case 5:
		//48MHz
		valeue=5;
		break;
	default:
		return ; 
	}

	GPIO_Address=1;

	if((errCode = PL2303_SetClock(hCOM, GPIO_Address,  valeue)) != STATUS_SUCCESS) {
		str.Format("PL2303_SetClock GPIO_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_SetClock GPIO_%d , %s MHz Successfully!",GPIO_Address, str_Text);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnCbnSelchangeComboPi0Led()
{
	// TODO: Add your control notification handler code here
	BYTE valeue;
	CString str_Text;
	CComboBox* cb = (CComboBox *)GetDlgItem(IDC_COMBO_PI0_LED);
	int nIndex = cb->GetCurSel();
	cb->GetLBText(nIndex, str_Text);
	
	switch(nIndex)
	{
	case 0:
		//Tx LED
		valeue=0;
		break;
	case 1:
		//Rx LED
		valeue=1;
		break;
	case 2:
		//Tx & Rx LED
		valeue=2;
		break;
	default:
		return ; 
	}

	GPIO_Address=0;

	if((errCode = PL2303_SetLED(hCOM, GPIO_Address,  valeue)) != STATUS_SUCCESS) {
		str.Format("PL2303_SetLED PI_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_SetLED PI_%d , %s LED Successfully!",GPIO_Address, str_Text);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnCbnSelchangeComboPi1Led()
{
	// TODO: Add your control notification handler code here
	BYTE valeue;
	CString str_Text;
	CComboBox* cb = (CComboBox *)GetDlgItem(IDC_COMBO_PI1_LED);
	int nIndex = cb->GetCurSel();
	cb->GetLBText(nIndex, str_Text);
	
	switch(nIndex)
	{
	case 0:
		//Tx LED
		valeue=0;
		break;
	case 1:
		//Rx LED
		valeue=1;
		break;
	case 2:
		//Tx & Rx LED
		valeue=2;
		break;
	default:
		return ; 
	}

	GPIO_Address=1;

	if((errCode = PL2303_SetLED(hCOM, GPIO_Address,  valeue)) != STATUS_SUCCESS) {
		str.Format("PL2303_SetLED PI_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_SetLED PI_%d , %s LED Successfully!",GPIO_Address, str_Text);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedCheckGp0Led()
{
	// TODO: Add your control notification handler code here

	m_PIO_LED_Funcion = m_PIO_LED_Funcion ? false : true;

	
	GPIO_Address=0;

	if((errCode = PL2303_Enable_LED_Output(hCOM, GPIO_Address,  m_PIO_LED_Funcion)) != STATUS_SUCCESS) {
		str.Format("PL2303_Enable_LED_Output PI_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_Enable_LED_Output PI_%d Successfully!",GPIO_Address);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnBnClickedCheckGp1Led()
{
	// TODO: Add your control notification handler code here
	m_PI1_LED_Funcion = m_PI1_LED_Funcion ? false : true;

	
	GPIO_Address=1;

	if((errCode = PL2303_Enable_LED_Output(hCOM, GPIO_Address,  m_PI1_LED_Funcion)) != STATUS_SUCCESS) {
		str.Format("PL2303_Enable_LED_Output PI_%d Failed! - %d",GPIO_Address,errCode );
		
	}
	else {
         str.Format("PL2303_Enable_LED_Output PI_%d Successfully!",GPIO_Address);
	}
	AddResponseString(str);
}

void CSample_PL2303TBDlg::OnNMThemeChangedScrollbarPwm0Freq(NMHDR *pNMHDR, LRESULT *pResult)
{
	// This feature requires Windows XP or greater.
	// The symbol _WIN32_WINNT must be >= 0x0501.
	// TODO: Add your control notification handler code here
	*pResult = 0;
	/*
	int Pos=m_ScrollBar_PWM_FREQ.GetScrollPos();
	str.Format("GetScrollPos %d",Pos);
	AddResponseString(str);

	m_ScrollBar_PWM_FREQ.SetScrollPos(Pos,1);
*/
}

void CSample_PL2303TBDlg::OnNMThemeChangedScrollbarPwm0Duty(NMHDR *pNMHDR, LRESULT *pResult)
{
	// This feature requires Windows XP or greater.
	// The symbol _WIN32_WINNT must be >= 0x0501.
	// TODO: Add your control notification handler code here
	*pResult = 0;
}


void CSample_PL2303TBDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: Add your message handler code here and/or call default
	int minpos;
   int maxpos;
   BYTE inputBuffer[2];

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);

	int Pos_FREQ=m_ScrollBar_PWM_FREQ.GetScrollPos();
	//str.Format("GetScrollPos_FREQ %d",Pos_FREQ);
	//AddResponseString(str);

	inputBuffer[0]=Pos_FREQ;


	int Pos_DUT=m_ScrollBar_PWM_DUT.GetScrollPos();

    inputBuffer[1]=Pos_DUT;

	str.Format("GetScrollPos_FREQ: %d,  DUT: %d",Pos_FREQ,Pos_DUT);
	AddResponseString(str);
	
   pScrollBar->GetScrollRange(&minpos, &maxpos); 
   maxpos = pScrollBar->GetScrollLimit();

   // Get the current position of scroll box.
   int curpos = pScrollBar->GetScrollPos();

 
   // Determine the new position of scroll box.
   switch (nSBCode)
   {
   case SB_LEFT:      // Scroll to far left.
      curpos = minpos;
      break;

   case SB_RIGHT:      // Scroll to far right.
      curpos = maxpos;
      break;

   case SB_ENDSCROLL:   // End scroll.
      break;

   case SB_LINELEFT:      // Scroll left.
      if (curpos > minpos)
         curpos--;
      break;

   case SB_LINERIGHT:   // Scroll right.
      if (curpos < maxpos)
         curpos++;
      break;

   case SB_PAGELEFT:    // Scroll one page left.
   {
      // Get the page size. 
      SCROLLINFO   info;
      pScrollBar->GetScrollInfo(&info, SIF_ALL);
   
      if (curpos > minpos)
      curpos = max(minpos, curpos - (int) info.nPage);
   }
      break;

   case SB_PAGERIGHT:      // Scroll one page right.
   {
      // Get the page size. 
      SCROLLINFO   info;
      pScrollBar->GetScrollInfo(&info, SIF_ALL);

      if (curpos < maxpos)
         curpos = min(maxpos, curpos + (int) info.nPage);
   }
      break;

   case SB_THUMBPOSITION: // Scroll to absolute position. nPos is the position
      curpos = nPos;      // of the scroll box at the end of the drag operation.
      break;

   case SB_THUMBTRACK:   // Drag scroll box to specified position. nPos is the
      curpos = nPos;     // position that the scroll box has been dragged to.
      break;
   }

   // Set the new position of the thumb (scroll box).
   pScrollBar->SetScrollPos(curpos);

  // GPIO_Address=1;

	if((errCode = PL2303_Set_PWM_Output(hCOM, PWM_Address,  inputBuffer)) != STATUS_SUCCESS) {
		str.Format("PL2303_Set_PWM_Output PWM_%d Failed! - %d",PWM_Address,errCode );
		
	}
	else {
         str.Format("PL2303_Set_PWM_Output PWM_%d Successfully!",PWM_Address);
	}
	AddResponseString(str);

  // CView::OnHScroll(nSBCode, nPos, pScrollBar);

}


void CSample_PL2303TBDlg::OnCbnSelchangeComboPwm()
{
	// TODO: Add your control notification handler code here
	
	CString str_Text;
	CComboBox* cb = (CComboBox *)GetDlgItem(IDC_COMBO_PWM);
	int nIndex = cb->GetCurSel();
	cb->GetLBText(nIndex, str_Text);
	
	switch(nIndex)
	{
	case 0:
		//DTR
		PWM_Address=0;
		break;
	case 1:
		//DCD
		PWM_Address=1;
		break;
	case 2:
		//DSR
		PWM_Address=2;
		break;
	case 3:
		//CTS
		PWM_Address=3;
		break;
	default:
		return ; 
	}

}

void CSample_PL2303TBDlg::OnBnClickedButton2()
{
	// TODO: Add your control notification handler code here
	
	if(hCOM != INVALID_HANDLE_VALUE) {
		CloseHandle(hCOM);
		hCOM = INVALID_HANDLE_VALUE;
	}
	OnCancel();
}

void CSample_PL2303TBDlg::OnBnClickedButton3()
{
	// TODO: Add your control notification handler code here
	CListBox* response = (CListBox *)GetDlgItem(IDC_LIST_COMMAND_RESPONSE);
	response->ResetContent();	
}

void CSample_PL2303TBDlg::OnBnClickedButton4()
{
	if(setBrz==0){
	setBrz = 1;	
	pThreadBrz->ResumeThread();
	str.Format("PL2303_12GPIO_Breathing START!");
	AddResponseString(str);
	}
	else{
	pThreadBrz->SuspendThread();
	str.Format("PL2303_12GPIO_Breathing STOP!");
	AddResponseString(str);
	setBrz = 0;
	}
#if 0
	// TODO: �b���[�J����i���B�z�`���{���X
	 BYTE inputBuffer[2];
	 int Pos_FREQ = 1;
	 int Pos_DUT = 1;
	 int m,n,j;
	 PWM_Address = 0;
	 for(m=0;m<5;m++)
	 {	
		 for(n=250;n>79;n=n-20)
		 {	
			 Pos_DUT =n;
			 Pos_FREQ = 250;
			 inputBuffer[0]=Pos_FREQ;
			 inputBuffer[1]=Pos_DUT;
			 str.Format("GetScrollPos_FREQ: %d,  DUT: %d",Pos_FREQ,Pos_DUT);
			 AddResponseString(str);
			 for(j=0;j<4;j++)
			 {
				 if((errCode = PL2303_Set_PWM_Output(hCOM, j,  inputBuffer)) != STATUS_SUCCESS) {
					str.Format("PL2303_Set_PWM_Output PWM_%d Failed! - %d",j,errCode );
					
				}
				else {
					 str.Format("PL2303_Set_PWM_Output PWM_%d Successfully!",j);
				}
				AddResponseString(str);
				Sleep(250-n);
				
			 }
		 }
		
		 for(n=80;n<251;n=n+24)
		 {	
			 Pos_DUT =n;
			 Pos_FREQ = 250;
			 inputBuffer[0]=Pos_FREQ;
			 inputBuffer[1]=Pos_DUT;
			 str.Format("GetScrollPos_FREQ: %d,  DUT: %d",Pos_FREQ,Pos_DUT);
			 AddResponseString(str);
			 for(j=0;j<4;j++)
			 {
				 if((errCode = PL2303_Set_PWM_Output(hCOM, j,  inputBuffer)) != STATUS_SUCCESS) {
					str.Format("PL2303_Set_PWM_Output PWM_%d Failed! - %d",j,errCode );
					
				 }
				 else{
					 str.Format("PL2303_Set_PWM_Output PWM_%d Successfully!",j);
				}
				AddResponseString(str);
				Sleep(340-n);
			 }
		 }
		 
	 }
#endif
}



void CSample_PL2303TBDlg::OnBnClickedButton5()
{
	int m;
	BYTE SweepAry[15] = {9,10,8,11,7,0,4,5,4,0,7,11,8,10,9};
	val=1;
	m_bGP0Enable = true;
	if(setSwp==0){
		for(m=0;m<8;m++)
		{
			GPIO_Address = SweepAry[m];
			if((errCode = PL2303_12GPIO_ENABLE(hCOM, GPIO_Address,  m_bGP0Enable)) != STATUS_SUCCESS) {
			str.Format("PL2303_12GPIO_ENABLE GPIO_%d Failed! - %d",GPIO_Address,errCode );
			AddResponseString(str);
			}	
		}
	setSwp = 1;	
	pThreadSwp->ResumeThread();
	str.Format("PL2303_12GPIO_Scrolling Start!");
	AddResponseString(str);
	}
	else{
	pThreadSwp->SuspendThread();
	str.Format("PL2303_12GPIO_Scrolling Stop!");
	AddResponseString(str);
	setSwp=0;
	}
#if 0	
	for(m=0;m<15;m++)
	{
		for(n=0;n<8;n++)//Set all the LED off
		{
			GPIO_Address = SweepAry[n];
			if((errCode = PL2303_12GPIO_SetValue(hCOM, GPIO_Address, 1)) != STATUS_SUCCESS) {
			str.Format("PL2303_12GPIO_CLEAR GPIO_%d Failed! - %d",GPIO_Address,errCode );
			AddResponseString(str);
			}
		}
		
	
		GPIO_Address = SweepAry[m];//Lighting the LED in sequence
		if((errCode = PL2303_12GPIO_SetValue(hCOM, GPIO_Address, 0)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_SET GPIO_%d Failed! - %d",GPIO_Address,errCode );
		AddResponseString(str);
				
		}
		Sleep(250);
	}
	str.Format("PL2303_SWEEPING_Finish!");
	AddResponseString(str);

	for(n=0;n<8;n++)//Set all the LED off
	{
		GPIO_Address = SweepAry[n];
		if((errCode = PL2303_12GPIO_SetValue(hCOM, GPIO_Address, 1)) != STATUS_SUCCESS) {
		str.Format("PL2303_12GPIO_CLEAR GPIO_%d Failed! - %d",GPIO_Address,errCode );
		AddResponseString(str);
		}
	}
#endif	
}



//HANDLE g_hCOM;
//CWinThread* pThread;
UINT ThreadBrz(LPVOID Param)
{
	BYTE inputBuffer[2];
	int Pos_FREQ = 1;
	int Pos_DUT = 1;
	int m,n,j;
	int ret;

	__int8 PWM_Address;
	PWM_Address = 0 ;
	while(1)
	{
	for(m=0;m<5;m++)
	 {	
		 for(n=250;n>79;n=n-20)
		 {	
			 Pos_DUT =n;
			 Pos_FREQ = 250;
			 inputBuffer[0]=Pos_FREQ;
			 inputBuffer[1]=Pos_DUT;
			 //str.Format("GetScrollPos_FREQ: %d,  DUT: %d",Pos_FREQ,Pos_DUT);
			 //AddResponseString(str);
			 for(j=0;j<4;j++)
			 {
				 if((ret = PL2303_Set_PWM_Output(Param, j,  inputBuffer)) != STATUS_SUCCESS) {
					//str.Format("PL2303_Set_PWM_Output PWM_%d Failed! - %d",j,errCode );
					
				}
				else {
					 //str.Format("PL2303_Set_PWM_Output PWM_%d Successfully!",j);
				}
				//AddResponseString(str);
				Sleep(250-n);
				
			 }
		 }
		
		 for(n=80;n<251;n=n+24)
		 {	
			 Pos_DUT =n;
			 Pos_FREQ = 250;
			 inputBuffer[0]=Pos_FREQ;
			 inputBuffer[1]=Pos_DUT;
			 //str.Format("GetScrollPos_FREQ: %d,  DUT: %d",Pos_FREQ,Pos_DUT);
			 //AddResponseString(str);
			 for(j=0;j<4;j++)
			 {
				 if((ret = PL2303_Set_PWM_Output(Param, j,  inputBuffer)) != STATUS_SUCCESS) {
					//str.Format("PL2303_Set_PWM_Output PWM_%d Failed! - %d",j,errCode );
					
				 }
				 else{
					 //str.Format("PL2303_Set_PWM_Output PWM_%d Successfully!",j);
				}
				//AddResponseString(str);
				Sleep(340-n);
			 }
		 }
		 
	 }
	}
	return TRUE;
}

UINT ThreadSwp(LPVOID Param)
{
	int m,n;
	int ret;
	__int8 GPIO_Address;
	BYTE SweepAry[15] = {9,10,8,11,7,0,4,5,4,0,7,11,8,10,9};
	while(1)
	{
		for(m=0;m<15;m++)
		{
			for(n=0;n<8;n++)//Set all the LED off
			{
				GPIO_Address = SweepAry[n];
				if((ret = PL2303_12GPIO_SetValue(Param, GPIO_Address, 1)) != STATUS_SUCCESS) {
				//str.Format("PL2303_12GPIO_CLEAR GPIO_%d Failed! - %d",GPIO_Address,errCode );
				//AddResponseString(str);
				}
			}
			
		
			GPIO_Address = SweepAry[m];//Lighting the LED in sequence
			if((ret = PL2303_12GPIO_SetValue(Param, GPIO_Address, 0)) != STATUS_SUCCESS) {
			//str.Format("PL2303_12GPIO_SET GPIO_%d Failed! - %d",GPIO_Address,errCode );
			//AddResponseString(str);
					
			}
			Sleep(250);
		}
		

		for(n=0;n<8;n++)//Set all the LED off
		{
			GPIO_Address = SweepAry[n];
			if((ret = PL2303_12GPIO_SetValue(Param, GPIO_Address, 1)) != STATUS_SUCCESS) {
			//str.Format("PL2303_12GPIO_CLEAR GPIO_%d Failed! - %d",GPIO_Address,errCode );
			//AddResponseString(str);
			}
		}
	Sleep(500);
	}
	return TRUE;
}

BOOL CSample_PL2303TBDlg::CreThrd()
{
	pThreadBrz = AfxBeginThread(ThreadBrz, hCOM, THREAD_PRIORITY_NORMAL,0, CREATE_SUSPENDED,NULL);
	pThreadSwp = AfxBeginThread(ThreadSwp, hCOM, THREAD_PRIORITY_NORMAL,0, CREATE_SUSPENDED,NULL);
	return TRUE;
}
bool CSample_PL2303TBDlg::PeekAndPump(void)
{
	MSG msg;

	while(::PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE)) {
		if(!AfxGetApp()->PumpMessage()) {
			::PostQuitMessage(0);
			return false;
		}
	}

	LONG lIdle = 0;
	while(AfxGetApp()->OnIdle(lIdle++)) ;

	return true;
}

bool CSample_PL2303TBDlg::Delay(int delay)
{
	DWORD beginCount;

	beginCount = ::GetTickCount();

	while(true) {
		if(!PeekAndPump())
			return false;
/*
		if(m_bCancel)
			return false;
*/
		if((long(::GetTickCount()) - long(beginCount)) > delay)
			return true;
	} 
}
void CSample_PL2303TBDlg::OnBnClickedButton6()
{
	// TODO: Add your control notification handler code here

		CString str;
	DWORD byteWritten = 0;	
	int i, j;
	BOOL bCompareFailed;
	OVERLAPPED ov;
//	char *endstring;
    HANDLE m_hCOM;

	UpdateData();


	m_hCOM= hCOM; 

	if(m_hCOM == INVALID_HANDLE_VALUE) {
		str = "Choose a COM port to write data.";
		AddResponseString(str);
		return;
	}

	int dataLen =30;
	int totalTimes =1;
	//int fixVal = 85; // 0x55
	int times = totalTimes;

	//int val = glb_val;

	while(times--) {
	  unsigned char *buffer = new unsigned char[dataLen];
		unsigned char *bak_buffer = new unsigned char[dataLen];
/*
  for(i=0;i<dataLen;i++)
//	for(i=dataLen-1;i>=0;i--)
  	buffer[i] = glb_val++;
*/
		// new method
//		BYTE temp;

		for(i=0;i<dataLen;i++) {
			
			buffer[i] = i;

			bak_buffer[i] = buffer[i];
		}

		memset(&ov, 0, sizeof(ov));
		ov.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);	// manual-reset
	
		BOOL bSuccess = ::WriteFile(m_hCOM, buffer, dataLen, &byteWritten, &ov);

		WaitForSingleObject(ov.hEvent, 10000);
		GetOverlappedResult(m_hCOM, &ov, &byteWritten, TRUE);

		CloseHandle(ov.hEvent);

		if(times == 0) {
			//str.Format("WRITE %ld bytes Successfully!", byteWritten);
			str.Format("WRITE bytes Successfully!", byteWritten);
			AddResponseString(str);
		}

		if(times != 0) {
			str.Format("Test times: %d", totalTimes - times);
			AddResponseString(str);
		}

		memset(buffer, 0, dataLen);

		Delay(800);
		//Sleep(100);

		// compare data
		if(times == 0) {
			str.Format("Comparing data...");
			AddResponseString(str);
		}

		DWORD byteRead = 0;

		HANDLE hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);		// manual-set
		OVERLAPPED ov;
		memset(&ov, 0, sizeof(ov));
		ov.hEvent = hEvent;

		bSuccess = ::ReadFile(m_hCOM, buffer, dataLen, &byteRead, &ov);

		WaitForSingleObject(ov.hEvent, 3000);
		GetOverlappedResult(m_hCOM, &ov, &byteRead, TRUE);

		CloseHandle(hEvent);

		if(byteRead == 0) {
		
		
		str = "READ data FAILED.";
	     AddResponseString(str);
		break;
		}
		
	



		bCompareFailed = FALSE;

		DWORD firstFailPos = 0;

		if(byteRead != dataLen) {
			str.Format("Read FAILED! expected read %ld bytes, only read %ld bytes", dataLen, byteRead);
			AddResponseString(str);
			bCompareFailed = TRUE;
		}

		for(i=0;i<dataLen;i++) {
			//str.Format("Data%d: 0x%02X", i, buffer[i-1]);
		    //AddOutputString(str);
			if(buffer[i] != bak_buffer[i]) {
				str.Format("COMPARE FAILED! expected: 0x%02X - received: 0x%02X - count: %d",
						bak_buffer[i], buffer[i], i);
				AddResponseString(str);
				bCompareFailed = TRUE;
				if(firstFailPos == 0)
					firstFailPos = i;
//				break;
			}
		}

		val = 0;

		if(bCompareFailed) {
/*
		for(i = 0; i < dataLen; i++) {
			str.Format("Data%3d: 0x%02X", i, buffer[i]);
			AddOutputString(str);
		}
*/
			int start = firstFailPos - 5;
			if(start < 0)
				start = 0;

			for(j=start;j<(int)firstFailPos+5;j++) {
				str.Format("Data%3d: 0x%02X", j, buffer[j]);
				AddResponseString(str);
			}
		}
	
		delete[] buffer;
		delete[] bak_buffer;

		if(bCompareFailed && times) {
			str.Format("Loop Check Failed - times: %ld", totalTimes - times);
			AddResponseString(str);
			break;
		}
	}

	str = "Compare data Finished!";
	AddResponseString(str);
}
