// Sample_PL2303TB.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CSample_PL2303TBApp:
// See Sample_PL2303TB.cpp for the implementation of this class
//

class CSample_PL2303TBApp : public CWinApp
{
public:
	CSample_PL2303TBApp();

// Overrides
	public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CSample_PL2303TBApp theApp;