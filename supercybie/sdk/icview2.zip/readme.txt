ICybie Action Viewer - version 2.01

See instructions: http://aibohack.com/icybie/icview2.htm

DISCLAIMER: this is only a poor simulation of ICybie motion playback.

It is only intended to give you a rough indication of what the actions looklike.

Run them in your Super ICybie to see how they really look.

========================================================================
History:

Version 2.01 - performs actions based on the Walkup8A cartridge
    Repeated actions not supported
    rough names for some actions

Version 1.01 - performs skits and other actions based on the OLDROM

