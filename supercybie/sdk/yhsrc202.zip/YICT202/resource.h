//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by YICT.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDM_IMPORT                      0x0020
#define IDM_EXPORT                      0x0030
#define IDM_ADDTOOLS                    0x0040
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_YICT_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDD_NEWACTION                   130
#define IDD_MULTIACTION                 131
#define IDD_OPENDIALOG                  134
#define IDD_NEWNAME                     135
#define IDD_SOUNDPREVIEW                136
#define IDC_COMBO_WAG                   1000
#define IDC_LIST1                       1001
#define IDC_COMBO3                      1001
#define IDC_LIST2                       1002
#define IDC_ADD_ACTION                  1003
#define IDC_REMOVE_REACTION             1004
#define IDC_CHANGE_ACTION               1005
#define IDC_TYPE                        1006
#define IDC_COMBO_STRETCH               1007
#define IDC_TREE1                       1008
#define IDC_COMBO4                      1009
#define IDC_COMBO5                      1010
#define IDC_TYPE2                       1011
#define IDC_COMBO_IDLE                  1012
#define ID_SAVE                         1023
#define ID_SAVE_AND_TRANSFER            1024
#define IDC_EDIT1                       1025
#define ID_SAVE_AND_TRANSFER2           1025
#define IDC_PREVIEW_SOUNDS              1028
#define IDC_IMPORT_BEHAVIOR             1029
#define IDC_NOCHARGER                   1030
#define IDC_PLAY                        1031
#define IDC_DUAL                        1031
#define IDC_MUTEINIT                    1033

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
