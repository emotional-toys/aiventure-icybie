Very simple utility

See ICAUD for full sample
http://aibohack.com/icybie/othercrap.htm


