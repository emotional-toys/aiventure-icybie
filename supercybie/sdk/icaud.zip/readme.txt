Instructions for creating an ICybie with custom sounds
NOTE: tied to the generic 202 YICT-enable personality

-------------------- -------------------- --------------------

Step #1) Sound preparation:

First look at (and play) the existing 30 sounds:
http://www.aibohack.com/icybie/sounds.htm

The challenge is to find new sounds to replace the 30 built-in 
sounds, and do so in a reasonably consistent and entertaining way.

For example, in Cartman, instead of the standard peeing sound effect,
it is replaced with "let a man take a crap".

You can record you own sounds, search the Internet (but sound 
quality can be poor) or RIP the audio from CDs or DVDs (the best) to 
get new sounds and sound effects.


Sounds must be in a certain .WAV format: 8000Hz, 16 bit, mono.

Use the highest quality audio you can find. You should normalize the 
volume of the sound samples to make the sounds close to 100 or 120% 
of full amplitude (or just email me the files and I'll do it)

You are limited to about 37.5 seconds of sound (TOTAL!). That is not 
a lot of sound, so pick the best samples.

The total .WAV files should be no larger than 600KB (they get 
compressed 4:1)

If you can't find replacements for all 30 sounds, you can reuse some 
of the old sounds, and they don't eat up any additional ROM.

If you can, also include a "theme song" for your personality. 
Typically it will be short (filling in whatever leftover space there 
is). This should be replacement sound 30.

Name the custom sound files 01.WAV to 30.WAV for the original sound
it replaces.
When using the "Preview Sounds" feature of YICT, custom sounds will
show up after the 30 built in sounds, so custom sounds 01.wav will
really be Custom Sound 31 (similarly 30.wav will be Custom Sound 60).

-------------------- -------------------- --------------------

Step #2) Build it

	Copy the 30 .WAV files into the SAMPLE directory

    Step #2A) run MAKE1.BAT
            This will compress the 30 WAV files to 30 smaller ADP files

    Step #2B) run MAKE2.BAT
            This will combine the 30 ADP files and 'newcart.ic3' the
            generic personality

       This step may fail if there is not enough room !

-------------------- -------------------- --------------------

Step #3) If it doesn't fit - you must re-edit!

    Reduce the size of you WAV files.
    Be sure to run MAKE1.BAT before MAKE2.BAT after any changes.

    There are also tricks for reusing custom sounds or leaving them blank.
    You can edit SAMPLE.INI and hopefully figure it out from there.
    If you have 30 cool sounds and still can't make it fit,
    please send me an email.

-------------------- -------------------- --------------------

Step #4) Publishing
    Before releasing, you will probably want to change "SAMPLE"
        to a real name. Pick something unique, usually ending in 202.

-------------------- -------------------- --------------------

