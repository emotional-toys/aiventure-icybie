﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebUserControl_WithHttpContext : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblCount.Text = GetExpensiveCount("count").ToString();
    }

    public string GetExpensiveCount(string KeyID)
    {
        string strRef = string.Empty;
        string key = "count_data" + KeyID;
        object obj = HttpContext.Current.Items[key];
        int intCount = 0;
        if (obj != null)
        {   
            //Get from cache
            intCount = (int)obj;
            strRef = "From cache , ";
        }
        else
        {
            //Call Database query and get result and store
            intCount = 20;
            HttpContext.Current.Items[key] = intCount;
            strRef = "From Database , ";
        }
        return strRef + intCount.ToString();
    }
}